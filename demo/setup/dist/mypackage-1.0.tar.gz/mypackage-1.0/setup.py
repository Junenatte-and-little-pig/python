# -*- encoding: utf-8 -*-
from distutils.core import setup

setup(name="mypackage",
      version="1.0",
      url='None',
      license='None',
      description="这是我自己的包",
      platforms='windows10 and python 3.7.4',
      author="junenatte",
      author_email='sy5622_5@126.com')
